#!/usr/bin/env python
# coding: utf-8

# In[1]:


stra = "hi' 


# In[2]:


if True:
    print("hey")


# In[3]:


varx = 10
vary = 0
varz = 20


# In[4]:


varx/vary


# In[7]:


try:
    varz = varx/vary
    print("varz =", varz)
except ZeroDivisionError:
    print("you can not divide by zero, equating vary to 1")
    print("so now varz =", varx/1)
    
print("code continues")


# In[8]:


vary = 5

try:
    varz = varx/vary
    print("varz =", varw)
except ZeroDivisionError:
    print("you can not divide by zero, equating vary to 1")
    print("so now varz =", varx/1)
    
print("code continues")


# In[9]:


vary = 5

try:
    varz = varx/vary
    print("varz =", varw)
except ZeroDivisionError:
    print("you can not divide by zero, equating vary to 1")
    print("so now varz =", varx/1)
except NameError:
    print("check the names of your variables")
    
print("code continues")


# In[10]:


lista = ['aa', 'bb', 'ff', 'yy', 'ee', 'ss']

try:
    index = int(input())
    val = lista[index]
    print("val =", val)
except IndexError:
    print("gone wrong with index")
    # code for handling the error/exception
    
print("code continues")


# In[11]:


lista = ['aa', 'bb', 'ff', 'yy', 'ee', 'ss']

try:
    index = int(input())
    val = lista[index]
    print("val =", val)
except IndexError:
    print("gone wrong with index")
    # code for handling the error/exception
    
print("code continues")


# In[12]:


lista = ['aa', 'bb', 'ff', 'yy', 'ee', 'ss']

try:
    index = int(input())
    val = lista[index]
    print("val =", val)
except IndexError:
    print("gone wrong with index")
    # code for handling the error/exception
    
print("code continues")


# In[13]:


lista = ['aa', 'bb', 'ff', 'yy', 'ee', 'ss']

try:
    index = int(input())
    val = lista[index]
    print("val =", val)
except IndexError:
    print("gone wrong with index")
    # code for handling the error/exception
except:
    print("something went wrong, not sure what")
    
print("code continues")


# In[15]:


lista = ['aa', 'bb', 'ff', 'yy', 'ee', 'ss']

try:
    index = int(input())
    val = lista[index]
    print("val =", val)
print("hello")
except IndexError:
    print("gone wrong with index")
    # code for handling the error/exception
except:
    print("something went wrong, not sure what")

    
print("code continues")


# In[17]:


lista = ['aa', 'bb', 'ff', 'yy', 'ee', 'ss']

try:
    index = int(input())
    try:
        val = lista[ind]
        print("val =", val)
    except NameError:
        print("inner exception")
except IndexError:
    print("gone wrong with index")
    # code for handling the error/exception
except:
    print("something went wrong, not sure what")

    
print("code continues")


# In[18]:


lista = ['aa', 'bb', 'ff', 'yy', 'ee', 'ss']

try:
    try:
        index = int(input())
        val = lista[index]
        print("val =", val)
    except NameError:
        print("inner exception")
except IndexError:
    print("gone wrong with index")
    # code for handling the error/exception
except:
    print("something went wrong, not sure what")

    
print("code continues")


# In[19]:


def funca(la, lb):
    try:
        lc = la/lb
        return lc
    except ZeroDivisionError:
        print("passed a zero value")
        return None


# In[22]:


try:
    x = funca(10, "hi")
    print("x =", x)
except:
    print("something else went wrong")


# In[23]:


lista = ['aa', 'bb', 'ff', 'yy', 'ee', 'ss']

try:
    index = int(input())
    val = lista[index]
    print("val =", val)
except IndexError:
    print("gone wrong with index")
    # code for handling the error/exception
else:
    print("executing the else block")
finally:
    print("executing the finally block")

    
print("code continues")


# In[24]:


lista = ['aa', 'bb', 'ff', 'yy', 'ee', 'ss']

try:
    index = int(input())
    val = lista[index]
    print("val =", val)
except IndexError:
    print("gone wrong with index")
    # code for handling the error/exception
else:
    print("executing the else block")
finally:
    print("executing the finally block")

    
print("code continues")


# In[25]:


lista = ['aa', 'bb', 'ff', 'yy', 'ee', 'ss']

try:
    index = int(input())
    val = lista[index]
    print("val =", val)
except IndexError:
    print("gone wrong with index")
    # code for handling the error/exception
else:
    print("executing the else block")
finally:
    print("executing the finally block")

    
print("code continues")


# In[26]:


import time

while(True):
    print("hi")
    time.sleep(2)


# In[28]:


try:
    x = int(input("enter a positive value: "))
    if x <= 0:
        raise ValueError("negative number")
    else:
        print("go ahead with code")
except ValueError as data:
    print("rcvd data =", data)


# In[29]:


class AppError(Exception):
    "base class for exceptions"
    pass

class TooLarge(AppError):
    """value too large"""
    pass

class TooSmall(AppError):
    """value too small"""
    pass

value = 20


# In[30]:


while True:
    try:
        num = int(input("\nenter a number:\n"))
        if num < value:
            raise TooSmall
        elif num > value:
            raise TooLarge
        else:
            break
    except TooLarge:
        print(TooLarge.__doc__)
    except TooSmall:
        print(TooSmall.__doc__)
        
print("you got it right !!!")


# In[ ]:


while True:
    try:
        num = int(input("\nenter a number:\n"))
        if num < value:
            raise TooSmall
        elif num > value:
            raise TooLarge
        else:
            break
    except TooLarge:
        print(TooLarge.__doc__)
    except TooSmall:
        print(TooSmall.__doc__) 
        
print("you got it right !!!")

