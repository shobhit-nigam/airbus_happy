"""this is syed's colourful module
will help us extract some colours
"""


def blue():
    "this gets us blue"
    print("cool blue")

def yellow():
    print("bright yellow")    

def green():
    "dependency: needs blue & yellow"
    print("go green is a mixutre of")
    blue()
    yellow() 
    
    
data_a = 33
data_b = 44
